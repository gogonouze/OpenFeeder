<div class=plain>
    <?php
  	 include_once "component/module";
    ?>
</div>
