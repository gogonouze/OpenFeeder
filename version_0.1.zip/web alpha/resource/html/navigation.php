<nav>
  <ul class="compose">
    <?php
  	   include_once "component/navigation";
    ?>
  </ul>
</nav>
