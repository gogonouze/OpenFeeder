#language : python 3, SQLite
#author : C. Martin, U. EB-LEVADOUX
#version : 1.0
#date : 20-01-2020

import sqlite3 as sql
import os

def process_fill_up_db(file_name, db_name) :
    conn = sql.connect(db_name)
    cursor = conn.cursor()

    data ={'date' : None, 'time': None, 'site': None, 'machine': None, 'scenario': None, 'entity': None}
    file = open(file_name,"r")
    for line in file :
        data_brut = line.split(',')
        print(data_brut)
        print()
        data['date'] = data_brut[0]
        data['time'] = data_brut[1]
        data['site'] = data_brut[2]
        data['machine'] = data_brut[3]
        data['scenario'] = data_brut[4]
        data['entity'] = data_brut[5]

        print(data)
        print()
        cursor.execute('insert into SITE (Id) select ? where not exists(select * from SITE where Id=(?))',(data['site'],data['site'],))
        cursor.execute('insert into MACHINE (Id,IdSite) select ?,? where not exists(select * from MACHINE where Id=(?))',(data['machine'],data['site'],data['machine'],))
        cursor.execute('insert into ENTITY (Id,IdCaptureSite, CaptureDate) select ?,?,? where not exists(select * from ENTITY where Id=(?))',(data['entity'],data['site'],data['date'],data['entity'],))
        cursor.execute('update ENTITY set IdLastVisitedMachine = (?) where  Id = (?)', (data['machine'],data['entity'],))



    file.close()
    file.open(file_name,"w")
    file.write("")
    file.close()
    conn.commit()


def main() :
    check = True
    while (check) :
        file_name = input('fichier source : ')
        if (os.path.isfile(file_name)) :
            check = False
            print("Fichier trouvé")
            print("")
        else :
            check = True
            print("Fichier introuvable")
            print("")

    check = True
    while (check) :
        db_name = input('Base de donnée destination : ')
        if (os.path.isfile(db_name)) :
            check = False
            print("Fichier trouvé")
            print("")
        else :
            check = True
            print("Fichier introuvable")
            if (dialog_create_file()) :
                f = open(db_name,"w+")
                f.close()
                check = False

            print("")

    process_fill_up_db(file_name, db_name)
    input('\nOpération terminée.\nAppuyez sur ENTRÉE pour terminer...')

main()
