<header class="ornament">
  <p class="treeOfLife">
    <?php
      include_once "component/title";
    ?>
	</p>
</header>
