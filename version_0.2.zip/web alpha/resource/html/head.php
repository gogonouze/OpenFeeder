<title>
  <?php
    include_once "component/head";
  ?>
</title>

<meta charset = "utf-8"/>
<link rel="stylesheet" href="css/highlandSunset.css"/>
