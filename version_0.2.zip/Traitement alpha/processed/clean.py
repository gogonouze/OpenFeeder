file = open("readyForDataBase","w")
file.write("")
file.close()
